
[freeX, freeY] = findOccupiedCells(map);
save('espacioLibre1piso.mat', 'freeX', 'freeY');